// Classe CoordTex (coordenadas de textura)
// (C) Bruno de Oliveira Schneider - DCC - UFLA - Julho de 2017

#ifndef COORDTEX_H
#define COORDTEX_H

class CoordTex {
    public:
        double u;
        double v;
};

#endif
                                                                                                                                                                                 // (C) Bruno de Oliveira Schneider - Não é permitido divulgar esta implementação - Publishing this code is forbidden
